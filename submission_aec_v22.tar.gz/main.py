# SPDX-License-Identifier: MIT
"""Kagriculture Competition Entrypoint — AEC Robust Qualified Foundation."""

import os
import sys
from typing import Any, Dict, Optional

# Ensure local submission root is in sys.path
_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from aec.config import build_robust_qualified_config
from aec.integration.executor import AECExecutor

_EXECUTOR: Optional[AECExecutor] = None


def agent(observation: Dict[str, Any], configuration: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Kaggle competition agent entrypoint."""
    global _EXECUTOR
    step = int(observation.get("step", 0) or 0)

    if _EXECUTOR is None or step == 0:
        cfg = build_robust_qualified_config()
        local_v3 = os.path.join(_DIR, "submission_Vj_kc_v3.tar.gz")
        if os.path.exists(local_v3):
            cfg.v3_tarball_path = local_v3
        _EXECUTOR = AECExecutor(config=cfg)

    return _EXECUTOR.act(observation, configuration)
